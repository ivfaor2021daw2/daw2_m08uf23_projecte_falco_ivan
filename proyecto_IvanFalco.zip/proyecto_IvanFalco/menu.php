<html>
	<head>
		<title>
			MENÚ PRINCIPAL 
		</title>
	</head>
	<body>
		<h2> MENÚ PRINCIPAL DE L'APLICACIÓ D'ACCÉS</h2>
		<h3> <b>Fet per: Ivan Falcó</b> </h3>
		<a href="http://zend-ivfaor.fjeclot.net/proyecto_IvanFalco/visualitzar.php">Visualitzar usuaris</a><br>
		<a href="http://zend-ivfaor.fjeclot.net/proyecto_IvanFalco/afegir.php">Afegir usuaris</a><br>
		<a href="http://zend-ivfaor.fjeclot.net/proyecto_IvanFalco/modificar.php">Modificar usuaris</a><br>
		<a href="http://zend-ivfaor.fjeclot.net/proyecto_IvanFalco/esborrar.php">Esborrar usuaris</a><br>
		
	</body>
</html>